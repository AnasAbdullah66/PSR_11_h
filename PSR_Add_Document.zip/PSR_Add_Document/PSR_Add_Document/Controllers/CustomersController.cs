﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.Intrinsics.Arm;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using PSR_Add_Document.Models;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using NuGet.Protocol;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using System.IO;



namespace PSR_Add_Document.Controllers
{
    public class CustomersController : Controller
    {
        private readonly CustomerDbContext _context;
        private readonly IConfiguration _configuration;
        private IWebHostEnvironment environment;

        // SessionCustomer 



        public const string SessionAccountNo = "SessionAccountNo";
        public const string SessionCustomerName = "SessionCustomerName";
        public const string SessionCustomerId = "SessionCustomerId";

        public CustomersController(CustomerDbContext context, IConfiguration configuration, IWebHostEnvironment environment)
        {
            _context = context;
            _configuration = configuration;
            this.environment = environment;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return _context.Customers != null ?
                        View(await _context.Customers.ToListAsync()) :
                        Problem("Entity set 'CustomerDbContext.Customers'  is null.");

        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerId,CustomerName,AccountNumber,Address,MobileNumber,Gender,Brn,DOB,Email")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }


        // POST: Customers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerId,CustomerName,AccountNumber,Address,MobileNumber,Gender,Brn,DOB")] Customer customer)
        {
            if (id != customer.CustomerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.CustomerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }


        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }


        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Customers == null)
            {
                return Problem("Entity set 'CustomerDbContext.Customers'  is null.");
            }
            var customer = await _context.Customers.FindAsync(id);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return (_context.Customers?.Any(e => e.CustomerId == id)).GetValueOrDefault();
        }



        //Otp add page

        public IActionResult OTP()
        {

            return View();
        }





        public async Task<IActionResult> Login(int? id, Customer model)
        {



            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }


            HttpContext.Session.SetString(SessionAccountNo, customer.AccountNumber);
            HttpContext.Session.SetString(SessionCustomerName, customer.CustomerName);
            HttpContext.Session.SetInt32(SessionCustomerId, customer.CustomerId);




            return View(customer);

        }


        private bool verifyOtp(string enterdOtp, string generateOtp)
        {
            return enterdOtp.Equals(generateOtp);
        }




        [HttpPost]
        public IActionResult SubmitOtp([FromForm] int finalDigit)
        {
            int a = Convert.ToInt32(TempData["otp"]);
            if (finalDigit == null)
            {
                return NoContent();
            }

            else if ((DateTime.Now - Convert.ToDateTime(TempData["timestamp"])).TotalMinutes > 30)
            {
                return BadRequest("OTP Timedout");
            }
            else if (finalDigit.ToString() == Convert.ToString(a))
            {
                return Ok("OTP Accepted");
            }
            else
            {
                return BadRequest("Please Enter Valid OTP");
            }
        }


        private string GenerateOTP()
        {
            const int otpLength = 4;
            const string characters = "0123456789";
            var random = new Random();
            var otp = new char[otpLength];

            for (int i = 0; i < otpLength; i++)
            {
                otp[i] = characters[random.Next(characters.Length)];
            }

            return new string(otp);
        }



        [HttpPost]
        public IActionResult VerifyOTP(OtpVerificationOptions model)
        {
            if (ModelState.IsValid)
            {
                if (TempData.TryGetValue("OTP", out object otp) &&
                    TempData.TryGetValue("MobileNumber", out object mobileNumber) &&
                    otp.ToString() == model.OTP && mobileNumber.ToString() == model.MobileNumber)
                {
                    TempData.Remove("OTP");
                    TempData.Remove("MobileNumber");

                    ViewBag.SuccessMessage = "OTP verification successful!";
                    return View();
                }

                ModelState.AddModelError("", "Invalid OTP");
            }
            return View(/*model*/);
        }

        [HttpGet]
        public IActionResult VerifyOTP()
        {
            if (TempData.TryGetValue("MobileNumber", out object mobileNumber))
            {
                TempData.Keep("MobileNumber");
                return View(new Customer { MobileNumber = mobileNumber.ToString() });
            }

            return View();
            //return RedirectToAction("Index");
        }



        public IActionResult ViewDocuments()
        {
            var documents = _context.CustomerDocuments.ToList(); // Fetch the documents from the database

            return View(documents);
        }

        public IActionResult AddDocument()
        {
            VMCustomerDocument objVMCustomerDocument = new VMCustomerDocument();

            objVMCustomerDocument.AccountNumber = HttpContext.Session.GetString(SessionAccountNo);
            objVMCustomerDocument.CustomerName = HttpContext.Session.GetString(SessionCustomerName);
            objVMCustomerDocument.CustomerId = HttpContext.Session.GetInt32(SessionCustomerId) ?? 0;

            ViewBag.AccountNumber = objVMCustomerDocument.AccountNumber;
            ViewBag.CustomerName = objVMCustomerDocument.CustomerName;
            ViewBag.CustomerId = objVMCustomerDocument.CustomerId;

            return View(objVMCustomerDocument);
        }


        //public IActionResult AddDocument()
        //{

        //    //HttpContext.Session.SetInt32(SessionCustomerId, customer.CustomerId);
        //    //HttpContext.Session.SetString(SessionAccountNo, customer.AccountNumber);

        //    VMCustomerDocument objVMCustomerDocument = new VMCustomerDocument();



        //    objVMCustomerDocument.AccountNumber = HttpContext.Session.GetString(SessionAccountNo);
        //    objVMCustomerDocument.CustomerName = HttpContext.Session.GetString(SessionCustomerName);
        //    objVMCustomerDocument.CustomerId = Convert.ToInt32(HttpContext.Session.GetInt32(SessionCustomerId));
        //    ViewBag.AccountNumber = HttpContext.Session.GetString(SessionAccountNo);
        //    ViewBag.CustomerName = HttpContext.Session.GetString(SessionCustomerName);
        //    ViewBag.CustomerId = HttpContext.Session.GetInt32(SessionCustomerId);
        //    return View(objVMCustomerDocument);
        //    //return RedirectToAction(nameof(Index));
        //}

        //    [HttpPost]
        //    public IActionResult AddDocument(VMCustomerDocument vmCustomerDocument)
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            var customerDocument = new CustomerDocument
        //            {
        //                CustomerName = vmCustomerDocument.CustomerName,
        //                AccountNumber = vmCustomerDocument.AccountNumber,
        //                TinNumber = vmCustomerDocument.TinNumber,
        //                AssesmentYear = vmCustomerDocument.AssesmentYear
        //            };

        //            if (vmCustomerDocument.Document != null && vmCustomerDocument.Document.Length > 0)
        //            {
        //                string uploadsFolder = Path.Combine(environment.WebRootPath, "Images");
        //                string uniqueFileName = Guid.NewGuid().ToString() + "_" + vmCustomerDocument.Document.FileName;
        //                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

        //                using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        //                {
        //                    vmCustomerDocument.Document.CopyTo(fileStream);
        //                }

        //                // Save the uniqueFileName to the database or perform other operations

        //                return RedirectToAction("Index"); // Redirect to the desired action after successful upload
        //            }
        //            else
        //            {
        //                ModelState.AddModelError(string.Empty, "Please choose a file to upload.");
        //            }
        //        }

        //        return View(vmCustomerDocument);
        //    }
        //}

        //[HttpPost]
        //public IActionResult AddDocument(CustomerDocument cusDoc, IFormFile file)
        //{
        //    var documents = _context.CustomerDocuments.ToList();
        //    if (ModelState.IsValid)
        //    {
        //        var customerDocument = new CustomerDocument
        //        {
        //            CustomerId = cusDoc.CustomerId,
        //            CustomerName = cusDoc.CustomerName,
        //            AccountNumber = cusDoc.AccountNumber,
        //            TinNumber = cusDoc.TinNumber,
        //            AssesmentYear = cusDoc.AssesmentYear,
        //            // Assign other properties from cusDoc to customerDocument
        //        };

        //        if (file != null && file.Length > 0)
        //        {
        //            string uploadsFolder = Path.Combine(environment.WebRootPath, "Images");
        //            string uniqueFileName = Guid.NewGuid().ToString() + "_" + file.FileName;
        //            string filePath = Path.Combine(uploadsFolder, uniqueFileName);

        //            using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        //            {
        //                file.CopyTo(fileStream);
        //            }

        //            // You can omit the DocumentPath assignment if not needed
        //            // customerDocument.DocumentPath = uniqueFileName;

        //            _context.CustomerDocuments.Add(customerDocument);
        //            _context.SaveChanges();

        //            return RedirectToAction("Index"); // Redirect to the desired action after successful upload
        //        }
        //        else
        //        {
        //            // Return an error response if the file is not found
        //            ModelState.AddModelError(string.Empty, "Please choose a file to upload.");
        //            return View(new CustomerDocument());
        //        }
        //    }
        //    else
        //    {
        //        // Model state is not valid, return the form with validation errors
        //        return View(cusDoc);
        //    }
        //}

        //[HttpPost]
        //public IActionResult AddDocument(CustomerDocument cusDoc, IFormFile file)
        //{
        //    var documents = _context.CustomerDocuments.ToList();
        //    if (ModelState.IsValid)
        //    {
        //        var customerDocument = new CustomerDocument
        //        {
        //            CustomerId = cusDoc.CustomerId,
        //            CustomerName = cusDoc.CustomerName,
        //            AccountNumber = cusDoc.AccountNumber,
        //            TinNumber = cusDoc.TinNumber,
        //            AssesmentYear = cusDoc.AssesmentYear,
        //            // Assign other properties from cusDoc to customerDocument
        //        };

        //        if (file != null && file.Length > 0)
        //        {
        //            string uploadsFolder = Path.Combine(environment.WebRootPath, "Images");
        //            string uniqueFileName = Guid.NewGuid().ToString() + "_" + file.FileName;
        //            string filePath = Path.Combine(uploadsFolder, uniqueFileName);

        //            using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        //            {
        //                file.CopyTo(fileStream);
        //            }

        //            customerDocument.DocumentPath = uniqueFileName; // Set the DocumentPath property to the file name

        //            _context.CustomerDocuments.Add(customerDocument);
        //            _context.SaveChanges();

        //            return RedirectToAction("Index"); // Redirect to the desired action after successful upload
        //        }
        //        else
        //        {
        //            // Return an error response if the file is not found
        //            ModelState.AddModelError(string.Empty, "Please choose a file to upload.");
        //            //return View(cusDoc);
        //            return View(new CustomerDocument());
        //        }
        //    }
        //    else
        //    {
        //        // Model state is not valid, return the form with validation errors
        //        return View(cusDoc);
        //    }
        //}

        //ok without image
        //[HttpPost]
        //public IActionResult AddDocument(CustomerDocument cusDoc, IFormFile file)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var customerDocument = new CustomerDocument
        //        {
        //            CustomerId = cusDoc.CustomerId,
        //            CustomerName = cusDoc.CustomerName,
        //            AccountNumber = cusDoc.AccountNumber,
        //            //Address = customer.Address,
        //            //MobileNumber = customer.MobileNumber,
        //            //Gender = customer.Gender,
        //            //Brn = customer.Brn,
        //            //DOB = customer.DOB,
        //            TinNumber = cusDoc.TinNumber,
        //            AssesmentYear = cusDoc.AssesmentYear,
        //            //  other properties
        //        };
        //        //if (cusDoc.Document != null)
        //        //{
        //        //    string uploadsFolder = Path.Combine(environment.WebRootPath, "Images");
        //        //    string uniqueFileName = Guid.NewGuid().ToString() + "_" + cusDoc.Document;
        //        //    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

        //        //    using (FileStream fileStream = new FileStream(filePath, FileMode.Create)) ;



        //        _context.CustomerDocuments.Add(customerDocument);
        //        _context.SaveChanges();
        //        return View();
        //        //}
        //    }
        //    else
        //    {
        //        // Return an error response if the customer is not found
        //        return NotFound();
        //    }
        //}

        [HttpPost]
        public IActionResult AddDocument(VMCustomerDocument model)
        {
            //if (ModelState.IsValid)
            //{
                if (model.Document != null && model.Document.Length > 0)
                {
                    string uploadsFolder = Path.Combine(environment.WebRootPath, "Images");

                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Document.FileName;
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        model.Document.CopyTo(fileStream);
                    }

                    var customerDocument = new CustomerDocument
                    {
                        CustomerId = model.CustomerId,
                        CustomerName = HttpContext.Session.GetString(SessionCustomerName),
                        AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
                        TinNumber = model.TinNumber,
                        AssesmentYear = model.AssesmentYear,
                        DocumentPath = filePath,
                        Reference = model.Reference,
                        RefNumber = model.RefNumber
                    };

                    _context.CustomerDocuments.Add(customerDocument);
                    _context.SaveChanges();

                    //return View();
                return RedirectToAction("ViewDocuments");
                }
            else
            {
                return View();
            }
            //}

            //// If the model state is not valid or the document is not provided, return to the view with errors
            //return View(model);
        }

    }
}


